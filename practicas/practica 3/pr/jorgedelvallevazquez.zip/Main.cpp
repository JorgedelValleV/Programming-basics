// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#include "juego.h"
#include "puntuaciones.h"
const std::string INICIO = "TORTUGAS ROBOTICAS\n******************\n1. Jugar\n2. Mostrar puntuaciones\n0. Salir\nIntroduzca una opcion: ";
const std::string ERROR_PUNTUACIONES = "Hubo un error al abrir las puntuaciones. Se procedera a cerrar el juego\n";
const std::string ERROR_JUGAR = "Hubo un error, no se ha podido cargar el juego. Prueba de nuevo\n";
const std::string OPCION_INCORRECTA = "Opcion incorrecta. Introduzca una de las tres posibles: ";
char menu() {
	char opt = ' ';
	std::cout << INICIO;
	std::cin >> opt;
	while (opt < '0' || opt > '2') {
		std::cout << OPCION_INCORRECTA;
		std::cin >> opt;
	}
	return opt;
}
void resuelvePuntuaciones() {
	tPuntuaciones punt;
	if (cargar(punt)) {
		tPlayer p;
		char opt = menu();
		while (opt != '0') {
			p.puntuacion = 0;
			if (opt == '1') {
				p.nombre = resuelveJuego(p.puntuacion);
				if (p.nombre != ERROR_JUEGO)actualizarPuntuacion(punt, p);
				else std::cout << ERROR_JUGAR;
			}
			else if (opt == '2') {
				mostrarPuntuaciones(punt);
			}
			system("PAUSE");
			system("cls");
			opt = menu();
		}
		guardarPuntuaciones(punt);
	}
	else  std::cout << ERROR_PUNTUACIONES;
}
int main() {
	srand(time(NULL));
	resuelvePuntuaciones();
	system("PAUSE");
	return 0;
}