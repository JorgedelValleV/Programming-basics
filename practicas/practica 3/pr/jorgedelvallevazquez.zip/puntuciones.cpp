// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#include "puntuaciones.h"
//funcion que carga las puntuaciones de un archivo en un vector
bool cargar(tPuntuaciones & t) {
	std::ifstream entrada;
	entrada.open("puntuaciones.txt");
	if (entrada.is_open()) {
		while (!entrada.eof()) {
			tPlayer p;
			entrada >> p.nombre >> p.puntuacion;
			t.push_back(p);
		}
		entrada.close();
		return true;
	}
	else return true;
}
//funcion que escribe en un fichero las puntuaciones guardadas en un vector al final de la partida
void guardarPuntuaciones(const tPuntuaciones & puntos) {
	std::ofstream salida;
	salida.open("puntuaciones.txt");
	if (salida.is_open()) {
		for (int i = 0; i < puntos.size(); ++i) {
			if (i != 0)salida << '\n';
			salida << puntos[i].nombre << ' ' << puntos[i].puntuacion;
		}
		salida.close();
	}
	else std::cout << ERROR_AL_GUARDAR_PUNTUACIONES;
}
//funcion que muestra por pantalla las puntuaciones guardadas en un archivo antes del comienzo de la partida, es decir las nuevas partidas no modifican este archivo hasta que acabe la ejecucion
void mostrarPuntuaciones(const tPuntuaciones & puntos) {
	std::cout << "PUNTUACIONES:\n";
	for (int i = 0; i < puntos.size(); ++i) {
		std::cout << puntos[i].nombre << ' ' << puntos[i].puntuacion << '\n';
	}
}
//funcion que busca un nombre en un vector y devuelve su posicion, si no lo encuentra devuelve el valor -1, que sirve para identificar al jugador que hay que anadir al vector
int encontrarNombre(tPuntuaciones const & puntos, const std::string & str) {
	int pos = -1;
	for (int i = 0; i < puntos.size() && pos == -1; ++i) {
		if (puntos[i].nombre == str)pos = i;
	}
	return pos;
}
//funcion que dado un jugador con su puntuacion, si ya esta en el vecotr le suma la puntuacion, y si no esta lo incorpora al final
bool actualizarPuntuacion(tPuntuaciones & puntos, tPlayer const& p) {
	bool actualizado = false;
	int pos = encontrarNombre(puntos, p.nombre);
	if (pos != -1) {
		puntos[pos].puntuacion += p.puntuacion;
		actualizado = true;
	}
	else {
		puntos.push_back(p);
		actualizado = true;
	}
	return actualizado;
}