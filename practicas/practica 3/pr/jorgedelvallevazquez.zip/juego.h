// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#ifndef JUEGO_H
#define JUEGO_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
#include <conio.h>
#include "tablero.h"
#include "cartas.h"
const int NUMCARTAS_INICIO = 3;
const std::string ERROR_JUEGO = "error";//dato que devuelve resuelveJuego al main.cpp en el caso de que no pueda cargarse el juego
const std::string SECUENCIA = "Introduzca una secuencia de cartas: ";
const std::string ERROR_SECUENCIA = "\nERROR. Ha introducido una carta de la que no disponia, introduzca la secuencia con mas cuidado.\n";
const std::string ROBARoEJECUTAR = "Pulse R para robar o E para ejecutar una jugada:";
const std::string ERROR_OPCION = "Opcion no valida. Cerciorese de introducir una opcion correcta. ";
const std::string PEDIR_FICHERO = "Introduzca el nombre del fichero de tableros:(recuerde .txt): ";
const std::string PEDIR_NUMJUG = "Introduzca el numero de jugadores: ";
const std::string ERROR_NUMJUG = "Numero incorrecto de jugadores. ";
const std::string PEDIR_NOMBREJUG = "Introduzca el nombre del jugador ";
const std::string OBLIGAROBAR = "No tiene cartas en la mano.  Por obligacion debe robar carta.\n";
const std::string OBLIGAEJECUTAR = "No tiene cartas en la baraja. Por obligacion debe ejecutar jugada.\n";
enum tTecla { TAVANZA, TDERECHA, TIZQUIERDA, TLASER, TSALIR };
struct tJugador {
	std::string nombre;
	tMazo baraja;
	tMano mano;
	tCoordenada c;
};
struct tJuego {
	int numJug;
	int turno;
	std::vector<tJugador> array;
	tTablero t;
};
// funcion que lleva a cabo la accion de la tortuga y devuelve cierto si ha conseguido una joya
bool realizarMovimiento(tTablero  & t, tCoordenada& c, tVCartas const &v);
//funcion que crea las manos de los jugadores con tres cartas
void inicializarManos(tJuego & j);
//funcion que asigna a cada jugador las coordenadas de una toruga
void inicializarCoordenadas(tJuego & j);
//funcion que realiza la lectura de la jugada mediante teclas especiales y devuelve un tTecla que asociamos a un tCarta
tTecla leerTecla();
//funcion que carga un juego. Cargamos un tablero con el numero de jugadores solicitado. Identificamos a los jugadores y les creamos un mazo, una mano con 3 cartas y les asignamos una toruga. 
bool cargarJuego(tJuego & juego);
//funcion que muestra por pantalla el tablero y los jugadores con las cartas que tienen en la mano indicando que jugador tiene el turno
void mostrarJuego(const tJuego & juego);
//funcion que ejecuta un turno. Puede robar una carta del mazo y almacenarla en la mano, o bien ejecutar una jugada con las cartas que el juagador tiene en la mano. Devuelve cierto si encuentra una joya.
bool ejecutarTurno(tJuego &juego);
//funcion que crea un tablero vacio para luego facilitar la carga desde un fichero
tTablero tableroVacio();
//funcion que lleva a cabo la resolucion del juego. Ejecuta turnos hasta que un jugador consigue una joya cuyo nombre devuelve, ademas de la puntuacion obtenida que habia recibido por referencia
std::string resuelveJuego(int & puntuacionDelGanador);
#endif