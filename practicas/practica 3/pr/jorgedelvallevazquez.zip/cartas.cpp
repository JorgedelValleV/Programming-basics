﻿// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#include "cartas.h"
std::ostream & operator<<(std::ostream & entrada, tCarta & dato) {
	switch (dato) {
	case AVANZAR:std::cout << "A"; break;
	case GIRODERECHA:std::cout << "GD"; break;
	case GIROIZQUIERDA:std::cout << "GI"; break;
	case LASER:std::cout << "L"; break;
	}
	return entrada;
}
std::ostream & operator<<(std::ostream & entrada, tMazo & dato) {
	for (int i = 0; i < dato.numCartas; ++i) {
		std::cout << dato.v[(dato.inicio + i) % dato.v.size()] << ' ';
	}
	std::cout << '\n';
	return entrada;
}
//funcion que crea un mazo aleatorio con 18 cartas de avanzar, 8 de girar a la izquierda, 8 derecha y 4 laser
void crearMazoAleatorio(tMazo & m) {
	for (int i = 0; i < numAV; ++i)m.v.push_back(AVANZAR);
	for (int i = numAV; i < (numAV + numGI); ++i)m.v.push_back(GIROIZQUIERDA);
	for (int i = (numAV + numGI); i < (numAV + numGI + numGD); ++i)m.v.push_back(GIRODERECHA);
	for (int i = (numAV + numGI + numGD); i < (numAV + numGI + numGD + numPL); ++i)m.v.push_back(LASER);
	m.inicio = 0;
	m.finall = 0;
	m.numCartas = m.v.size();
	size_t aux = (rand() % 30) + 1;
	for (size_t i = 0; i < aux; ++i) {
		std::random_shuffle(m.v.begin(), m.v.end());
	}
}
//funcion que extrae una carta del mazo y devuelve cierto solo si se ha ejecutado, es decir, habia cartas en el mazo
bool cogerCarta(tMazo & mazo, tCarta & carta) {
	if (mazo.numCartas > 0) {
		carta = mazo.v[mazo.inicio];
		mazo.inicio = (mazo.inicio + 1) % mazo.v.size();
		--mazo.numCartas;
		return true;
	}
	return false;
}
//funcion que devuelve las cartas empleadas en la ejecucion de una jugada de forma aleatoria
void devolverCarta(tMazo & mazo, tVCartas &  v) {
	std::random_shuffle(v.begin(), v.end());
	for (int i = 0; i < v.size(); ++i) {
		mazo.v[mazo.finall] = v[i];
		mazo.finall = (mazo.finall + 1) % mazo.v.size();
	}
	mazo.numCartas += v.size();
	v.clear();
}
//funcion que incluye en la mano una carta robada del mazo(o una carta introducida en una secuencia no valida)
void incluirCarta(tMano &mano, tCarta carta) {
	switch (carta) {
	case AVANZAR:++mano[AVANZAR]; break;
	case GIROIZQUIERDA:++mano[GIROIZQUIERDA]; break;
	case GIRODERECHA:++mano[GIRODERECHA]; break;
	case LASER:++mano[LASER]; break;
	}
}