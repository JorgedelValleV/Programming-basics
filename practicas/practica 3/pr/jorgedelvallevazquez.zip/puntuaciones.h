// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#ifndef PUNTUACIONES_H
#define PUNTUACIONES_H

#include<iostream>
#include<string>
#include<fstream>
#include<vector>
const std::string ERROR_AL_GUARDAR_PUNTUACIONES = "Hubo un error al guardar las puntuaciones en el archivo.\n";
struct tPlayer {
	std::string nombre;
	int puntuacion;
};
using tPuntuaciones = std::vector<tPlayer>;
//funcion que carga las puntuaciones de un archivo en un vector
bool cargar(tPuntuaciones & t);
//funcion que escribe en un fichero las puntuaciones guardadas en un vector al final de la partida
void guardarPuntuaciones(const tPuntuaciones & puntos);
//funcion que muestra por pantalla las puntuaciones guardadas en un archivo antes del comienzo de la partida, es decir las nuevas partidas no modifican este archivo hasta que acabe la ejecucion
void mostrarPuntuaciones(const tPuntuaciones & puntos);
//funcion que busca un nombre en un vector y devuelve su posicion, si no lo encuentra devuelve el valor -1, que sirve para identificar al jugador que hay que anadir al vector
int encontrarNombre(tPuntuaciones const & puntos, const std::string & str);
//funcion que dado un jugador con su puntuacion, si ya esta en el vecotr le suma la puntuacion, y si no esta lo incorpora al final
bool actualizarPuntuacion(tPuntuaciones & puntos, tPlayer const& p);
#endif