// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#include "juego.h"
#include "checkML.h"
void liberarmazosjugadores(tJuego & j) {
	for (int i = 0; i < j.numJug; ++i)
		liberarmazo(j.array[i].baraja);
}
// funcion que lleva a cabo la accion de la tortuga y devuelve cierto si ha conseguido una joya
bool realizarMovimiento(tTablero  & t, tCoordenada & c, tVCartas const &v) {
	bool joya = false;
	tDir d = t[c.fila][c.columna].tortuga.direccion;
	for (int i = 0; i < v.size() && !joya; ++i) {
		switch (v[i]) {
		case AVANZAR:if (movPosible(t, c, d)) {
			joya = avanzar(t, c, d);
		}break;
		case GIRODERECHA: {
			++t[c.fila][c.columna].tortuga.direccion;
			d = t[c.fila][c.columna].tortuga.direccion;
		}break;
		case GIROIZQUIERDA: {
			--t[c.fila][c.columna].tortuga.direccion;
			d = t[c.fila][c.columna].tortuga.direccion;
		}break;
		case LASER:laser(t, c, t[c.fila][c.columna].tortuga.direccion); break;
		}
	}
	return joya;
}
//funcion que crea las manos de los jugadores con tres cartas
void inicializarManos(tJuego & j) {
	tMano m(NUMCARTAS_TIPOS);
	for (int i = 0; i < j.numJug; ++i) {
		j.array[i].mano = m;
		int k = 0;
		while (k < NUMCARTAS_INICIO) {
			tCarta c;
			cogerCarta(j.array[i].baraja, c);
			incluirCarta(j.array[i].mano, c);
			++k;
		}
	}
}
//funcion que asigna a cada jugador las coordenadas de una toruga
void inicializarCoordenadas(tJuego & j) {
	int encontradas = 0;
	for (int f = 0; f < DIMENSION && encontradas<j.numJug; ++f) {
		for (int c = 0; c < DIMENSION && encontradas<j.numJug; ++c) {
			if (j.t[f][c].contenido == TORTUGA) {
				encontradas++;
				j.array[encontradas - 1].c.fila = f;
				j.array[encontradas - 1].c.columna = c;
			}
		}
	}
}
//funcion que realiza la lectura de la jugada mediante teclas especiales y devuelve un tTecla que asociamos a un tCarta
tTecla leerTecla() {
	tTecla t;
	std::cin.sync();
	int dir = _getch(); // dir: tipo int 
	if (dir == 0xe0) {
		dir = _getch();
		switch (dir) {
		case 72:t = TAVANZA; std::cout << " ^ "; break;
		case 80:t = TAVANZA; std::cout << " ^ "; break;
		case 75:t = TIZQUIERDA; std::cout << " < "; break;
		case 77:t = TDERECHA; std::cout << " > "; break;
		}
	}
	else if (dir == 13) {
		t = TSALIR;
	}
	else if (dir == 32) {
		std::cout << " ~ ";
		t = TLASER;
	}
	return t;
}
//funcion que carga un juego. Cargamos un tablero con el numero de jugadores solicitado. Identificamos a los jugadores y les creamos un mazo, una mano con 3 cartas y les asignamos una toruga. 
bool cargarJuego(tJuego & juego) {
	std::cout << PEDIR_NUMJUG;
	std::cin >> juego.numJug;
	while (juego.numJug<MIN_JUG || juego.numJug> MAX_JUGADORES) {
		std::cout << ERROR_NUMJUG << PEDIR_NUMJUG;
		std::cin >> juego.numJug;
	}
	std::string nombreFich;
	std::cout << PEDIR_FICHERO;
	std::cin >> nombreFich;
	if (std::cin && cargar(juego.t, juego.numJug, nombreFich)) {
		juego.array = std::vector<tJugador>(juego.numJug);
		for (int i = 0; i < juego.numJug; ++i) {
			std::cout << PEDIR_NOMBREJUG << i + 1 << " :";
			std::cin >> juego.array[i].nombre;
			crearMazoAleatorio(juego.array[i].baraja);
		}
		inicializarManos(juego);
		inicializarCoordenadas(juego);
		return true;
	}
	else return false;
}
//funcion que muestra por pantalla el tablero y los jugadores con las cartas que tienen en la mano indicando que jugador tiene el turno
void mostrarJuego(const tJuego & juego) {
	system("cls");
	mostrarTablero(juego.t);
	std::cout << "JUGADORES:\n";
	for (int i = 0; i < juego.array.size(); ++i) {
		std::string num;
		std::stringstream ss; ss << (i + 1);
		ss >> num;
		std::string str = num + ". " + juego.array[i].nombre;
		colorFondo(PALETA[i + 5], 0);
		std::cout << std::setw(2) << std::left;
		if ((i + 1) == juego.turno)std::cout << "> ";
		else std::cout << "  ";
		std::cout << std::setw(20) << std::right << str;
		colorFondo(0);
		std::cout << std::setw(3) << std::right << juego.array[i].mano[AVANZAR];
		colorFondo(PALETA[9]);
		std::cout << " ^ ";
		colorFondo(0);
		std::cout << ' ' << juego.array[i].mano[GIROIZQUIERDA];
		colorFondo(PALETA[9]);
		std::cout << " < ";
		colorFondo(0);
		std::cout << ' ' << juego.array[i].mano[GIRODERECHA];
		colorFondo(PALETA[9]);
		std::cout << " > ";
		colorFondo(0);
		std::cout << ' ' << juego.array[i].mano[LASER];
		colorFondo(PALETA[9]);
		std::cout << " ~ ";
		colorFondo(0);
		std::cout << '\n';
	}
}
//funcion que ejecuta un turno. Puede robar una carta del mazo y almacenarla en la mano, o bien ejecutar una jugada con las cartas que el jugador tiene en la mano. Devuelve cierto si encuentra una joya.
bool ejecutarTurno(tJuego &juego) {
	bool joya = false;
	char c;
	if (juego.array[juego.turno - 1].mano[AVANZAR] == 0 && juego.array[juego.turno - 1].mano[GIRODERECHA] == 0 && juego.array[juego.turno - 1].mano[GIROIZQUIERDA] == 0 && juego.array[juego.turno - 1].mano[LASER] == 0) {
		std::cout << OBLIGAROBAR;
		c = 'r';
		system("PAUSE");
	}
	else if (juego.array[juego.turno - 1].baraja.numElem == 0) {
		std::cout << OBLIGAEJECUTAR;
		c = 'e';
		system("PAUSE");
	}
	else {//pide opcion si es posible robar al haber cartas en el mazo y es posible ejecutar al tener cartas en la mano
		std::cout << ROBARoEJECUTAR;
		std::cin >> c;
		while (c != 'e' && c != 'r' && c != 'E' && c != 'R') {
			std::cout << ERROR_OPCION << ROBARoEJECUTAR;
			std::cin >> c;
		}
	}
	if (toupper(c) == 'R') {
		tCarta c;
		if (cogerCarta(juego.array[juego.turno - 1].baraja, c)) {
			incluirCarta(juego.array[juego.turno - 1].mano, c);
		}
	}
	else if (toupper(c) == 'E') {
		std::cout << SECUENCIA;
		bool valido = true;
		tVCartas vc;
		tTecla t = leerTecla();
		while (t != TSALIR) {
			if (juego.array[juego.turno - 1].mano[tCarta(t)] > 0) {
				vc.push_back(tCarta(t));
				--juego.array[juego.turno - 1].mano[tCarta(t)];
			}
			else {
				valido = false;
			}
			if (!valido) {//se ejecuta si la jugada no es valida. devuelve a la mano las cartas utilizadas
				valido = true;
				std::cout << ERROR_SECUENCIA;
				for (size_t i = 0; i < vc.size(); ++i) {
					incluirCarta(juego.array[juego.turno - 1].mano, vc[i]);
				}
				vc.clear();
			}
			t = leerTecla();
		}
		joya = realizarMovimiento(juego.t, juego.array[juego.turno - 1].c, vc);
		devolverCarta(juego.array[juego.turno - 1].baraja, vc);
	}
	return joya;
}
//funcion que lleva a cabo la resolucion del juego. Ejecuta turnos hasta que un jugador consigue una joya cuyo nombre devuelve, ademas de la puntuacion obtenida que habia recibido por referencia
std::string resuelveJuego(int & puntuacionDelGanador) {
	tJuego j;
	j.turno = 1;
	j.t = tableroVacio();
	if (cargarJuego(j)) {
		mostrarJuego(j);
		while (!ejecutarTurno(j)) {
			j.turno = (j.turno % j.numJug) + 1;
			mostrarJuego(j);
		}
		liberarmazosjugadores(j);
		system("cls");
		mostrarTablero(j.t);
		colorFondo(PALETA[j.turno + 4], 0);
		std::cout << "\nHa ganado " << j.array[j.turno - 1].nombre << " y ha conseguido " << j.numJug << " puntos.\n";
		colorFondo(0);
		puntuacionDelGanador = j.numJug;
		return j.array[j.turno - 1].nombre;//devuelve el nombe del ganador. su puntuacion va por referencia
	}
	else return ERROR_JUEGO;//devuelve la palabra error para reconocer cuando no hay que actualizar la informacion
}