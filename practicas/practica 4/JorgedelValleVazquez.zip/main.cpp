// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#include "juego.h"
#include "puntuaciones.h"
#include "checkML.h"

#ifdef _DEBUG
#define DBG_NEW new (_NORMAL_BLOCK, __FILE__, __LINE__)
#define new DBG_NEW

const std::string INICIO = "TORTUGAS ROBOTICAS\n******************\n1. Jugar\n2. Mostrar puntuaciones\n0. Salir\nIntroduzca una opcion: ";
const std::string MOSTRAR_OPCIONES = "1. Mostrar por defecto\n2. Mostrar por orden alfabetico\nIntroduzca una opcion: ";
const std::string ERROR_PUNTUACIONES = "Hubo un error al abrir las puntuaciones. Se procedera a cerrar el juego\n";
const std::string ERROR_ACTUALIZAR = "Hubo un error al ACTUALIZAR las puntuaciones.\n";
const std::string ERROR_JUGAR = "Hubo un error, no se ha podido cargar el juego. Prueba de nuevo\n";
const std::string OPCION_INCORRECTA = "Opcion incorrecta. Introduzca una de las tres posibles: ";
char menu() {
	char opt = ' ';
	std::cout << INICIO;
	std::cin >> opt;
	while (opt < '0' || opt > '2') {
		std::cout << OPCION_INCORRECTA;
		std::cin >> opt;
	}
	return opt;
}
void resuelvePuntuaciones() {
	tPuntuaciones punt;
	punt.numJugadores = 0;
	punt.capacidad = TAM;
	punt.array_clasificacion = new tPlayer *[punt.capacidad];
	if (cargar(punt)) {
		tPlayer p;
		char opt = menu();
		while (opt != '0') {
			if (opt == '1') {
				p.puntuacion = 0;
				p.nombre = resuelveJuego(p.puntuacion);
				if (p.nombre != ERROR_JUEGO) {
					if (!actualizarPuntuacion(punt, p))std::cout << ERROR_ACTUALIZAR;
				}
				else std::cout << ERROR_JUGAR;
			}
			else if (opt == '2') {
				int orden;
				std::cout << MOSTRAR_OPCIONES;
				std::cin >> orden;
				if(orden == 1)mostrarPuntuaciones(punt);
				else if (orden == 2)mostrarAlfabetico(punt);
			}
			system("PAUSE");
			system("cls");
			opt = menu();
		}
		guardarPuntuaciones(punt);
	}
	else  std::cout << ERROR_PUNTUACIONES;
	liberar(punt);
}
int main() {
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	srand(time(NULL));
	resuelvePuntuaciones();
	_CrtDumpMemoryLeaks();
	system("PAUSE");
	return 0;
}
#endif