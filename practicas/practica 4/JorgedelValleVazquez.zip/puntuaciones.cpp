// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#include "puntuaciones.h"
#include "checkML.h"
bool compdefecto(tPlayer* p1, tPlayer* p2) {
	if (p1->puntuacion > p2->puntuacion || ((p1->puntuacion == p2->puntuacion) && (p1->nombre < p2->nombre)))
		return true;
	else return false;
}
bool compalfab(tPlayer* p1, tPlayer* p2) {
	if (p1->nombre < p2->nombre)
		return true;
	else return false;
}
//funcion que carga las puntuaciones de un archivo en un vector
bool cargar(tPuntuaciones & t) {
	std::ifstream entrada;
	entrada.open(ARCHIVO_CLASIFICACION);
	if (entrada.is_open()) {
		while (!entrada.eof()) {
			if (t.capacidad == t.numJugadores)redimensionar(t);//aumentamos la capacidad en 4 para seguir cargando todos los jugadores
			t.array_clasificacion[t.numJugadores] = new tPlayer;//le creamos una direccion de memoria al proximo jugador que cargamos
			entrada >> t.array_clasificacion[t.numJugadores]->nombre >> t.array_clasificacion[t.numJugadores]->puntuacion;
			++t.numJugadores;
		}
		entrada.close();
		return true;
	}
	else return true;
}
//funcion que escribe en un fichero las puntuaciones guardadas en un vector al final de la partida
void guardarPuntuaciones(const tPuntuaciones & puntos) {
	std::ofstream salida;
	salida.open(ARCHIVO_CLASIFICACION);
	if (salida.is_open()) {
		for (int i = 0; i < puntos.numJugadores; ++i) {
			if (i != 0)salida << '\n';
			salida << puntos.array_clasificacion[i]->nombre << ' ' << puntos.array_clasificacion[i]->puntuacion;
		}
		salida.close();
	}
	else std::cout << ERROR_AL_GUARDAR_PUNTUACIONES;
}
//funcion que muestra por pantalla las puntuaciones guardadas en un archivo antes del comienzo de la partida, es decir las nuevas partidas no modifican este archivo hasta que acabe la ejecucion
void mostrarPuntuaciones(const tPuntuaciones & puntos) {
	std::cout << "PUNTUACIONES:\n";
	for (int i = 0; i < puntos.numJugadores; ++i) {
		std::cout << puntos.array_clasificacion[i]->nombre << ' ' << puntos.array_clasificacion[i]->puntuacion << '\n';
	}
}
void ordenarInsercionAlfabetico(std::vector<tPlayer*> & array) {
	size_t	N = array.size();
	//	parte	ordenada	array[0..i),	parte	por	procesar	array[i..N)	
	for (size_t i = 1; i < N; ++i) {//	desde	el	segundo	hasta	el	�ltimo		
		//	parte	ordenada	array[0..i)			
		tPlayer *	elemento = array[i];		//	elemento	a	insertar	
		size_t	j = i;	//	desplazar	los	mayores	de	la	parte	ordenada	
		while (j > 0 && compalfab(elemento, array[j - 1])) {
			array[j] = array[j - 1];
			--j;
		}
		if (j != i)	array[j] = elemento;	//	colocar	en	el	hueco		
	}	//	parte	ordenada	array[0..N)	
}
//funcion que muestra por pantalla las puntuaciones ordenadas alfabeticamente
void mostrarAlfabetico(const tPuntuaciones & puntos) {
	std::vector<tPlayer*> vp;
	std::cout << "PUNTUACIONES:\n";
	for (int i = 0; i < puntos.numJugadores; ++i) {
		vp.push_back(puntos.array_clasificacion[i]);
	}
	ordenarInsercionAlfabetico(vp);
	for (size_t j = 0; j < vp.size(); ++j) {
		std::cout << vp[j]->nombre << ' ' << vp[j]->puntuacion << '\n';
	}
}
//funcion que busca un nombre en un vector y devuelve su posicion, si no lo encuentra devuelve el valor -1, que sirve para identificar al jugador que hay que anadir al vector
int encontrarNombre(tPuntuaciones const & puntos, const std::string & str) {
	int pos = -1;
	/*for (int i = 0; i < puntos.size() && pos == -1; ++i) {
		if (puntos[i].nombre == str)pos = i;
	}*/
	return pos;
}
//funcion que busca un nombre en la clasificacion.
bool buscarnomb(tPuntuaciones const & punt, std::string const & str, int & pos) {
	int i = 0; bool enc = false;
	while (i < punt.numJugadores && !enc) {
		pos = i;
		if (str == punt.array_clasificacion[i]->nombre)enc = true;
		++i;
	}
	return i < punt.numJugadores;
}
//funcion que busca la posicion que le corresponde a un jugador en la clasificacion.
bool buscar(tPuntuaciones const & punt, tPlayer  & p, int & pos) {
	size_t	ini = 0, fin = punt.numJugadores, mitad;
	bool	encontrado = false;
	//	0	<=	ini	<=	fin	<=	N	
	//	array[0..ini)	<	buscado	Y	buscado	<	array[fin..N)
	while (ini < fin && !encontrado) {
		mitad = (ini + fin - 1) / 2;	//	divisi�n	entera	
		if (compdefecto(&p, punt.array_clasificacion[mitad]))	fin = mitad;
		else if (compdefecto(punt.array_clasificacion[mitad] ,&p))	ini = mitad + 1;
		else encontrado = true;
	}
	if (encontrado)	pos = mitad;	//	en	la	posici�n	mitad					
	else	pos = ini;		//	No encontrado,	le	corresponde	la	posici�n	ini	(=fin)					
	return	encontrado;
}

//funcion que dado un jugador con su puntuacion, si ya esta en el vector le suma la puntuacion, y si no esta lo incorpora en la posicion que le corresponda determinada por la funcion buscar
bool actualizarPuntuacion(tPuntuaciones & puntos, tPlayer  & p) {
	bool actualizado = false;
	int pos;
	if (buscarnomb(puntos, p.nombre, pos)) {
		int pos2;
		p.puntuacion += puntos.array_clasificacion[pos]->puntuacion;
		buscar(puntos, p, pos2);//buscamos la posicion que le corresponde a la nueva puntuacion y colocamos al jugador en la posicion que le corresponda;
		puntos.array_clasificacion[pos]->puntuacion = p.puntuacion;//guardamos la nueva la puntuacion
		tPlayer * aux= puntos.array_clasificacion[pos];
		for (size_t i = pos; i > pos2; --i)//desplaza a la derecha desde la posicion en la que vamos a insertar
			puntos.array_clasificacion[i] = puntos.array_clasificacion[i - 1];
		puntos.array_clasificacion[pos2] = aux;
		actualizado = true;
	}
	else {
		buscar(puntos, p, pos);//buscamos la posicion en la que debemos colocar el nuevo jugador
		if (puntos.numJugadores == puntos.capacidad)redimensionar(puntos);
		++puntos.numJugadores;
		for (size_t i = puntos.numJugadores; i > pos; --i)//desplaza a la derecha desde la posicion en la que vamos a insertar
			puntos.array_clasificacion[i] = puntos.array_clasificacion[i - 1];
		puntos.array_clasificacion[pos] = new tPlayer;//puntos.array_clasificacion[pos] y[pos+1] apuntan a lo mismo. Por ello le creamos una nueva memoria.
		puntos.array_clasificacion[pos]->nombre = p.nombre;
		puntos.array_clasificacion[pos]->puntuacion = p.puntuacion;
		actualizado = true;
	}
	return actualizado;
}
void redimensionar(tPuntuaciones & clasificacion) {
	tPlayer ** aux = clasificacion.array_clasificacion;
	clasificacion.array_clasificacion = new tPlayer *[clasificacion.capacidad + TAM];
	for (int i = 0; i < clasificacion.numJugadores; ++i)
		clasificacion.array_clasificacion[i] = aux[i];
	delete[] aux;
	clasificacion.capacidad = clasificacion.capacidad + TAM;
}
void liberar(tPuntuaciones & clasificacion) {
	for (int i = 0; i < clasificacion.numJugadores; ++i)
		delete clasificacion.array_clasificacion[i];
	delete[] clasificacion.array_clasificacion;
	clasificacion.array_clasificacion = nullptr;
	clasificacion.numJugadores = 0;
	clasificacion.capacidad = 0;
}