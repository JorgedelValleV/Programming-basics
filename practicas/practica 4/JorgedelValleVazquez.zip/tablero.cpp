﻿// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#include "tablero.h"
#include "checkML.h"
tCoordenada operator+(tCoordenada & c1, tCoordenada & c2) {
	c2.fila += c1.fila;
	c2.columna += c1.columna;
	return c2;
}
//operadores incremento prefijo 
tDir operator++(tDir & dir) {
	dir = tDir((int(dir) + 1) % NUM_DIRECCIONES);
	return dir;
}
// incremento posfijo 
tDir operator++(tDir & dir, int) {
	tDir aux = dir;
	dir = tDir((int(dir) + 1) % NUM_DIRECCIONES);
	return aux;
}
//decremento prefijo
tDir operator--(tDir & dir) {
	dir = tDir((int(dir) + 3) % NUM_DIRECCIONES);//restar uno equivale a restar 3. Lo hago asi porque da error cuando resto 1 a 0 al no existir la dir -1
	return dir;
}
//funcion que crea un tablero vacio para luego facilitar la carga desde un fichero
tTablero tableroVacio() {
	tTablero t(DIMENSION, std::vector<tCasilla>(DIMENSION));
	return t;
}
//(a) Transformar un caracter en una casilla. La funcion recibira tambien un parametro con el identificador de la tortuga. Este parametro solo llevara valor cuando el caracter corresponda a una tortuga.
tCasilla charTOcasilla(char c, int n) {
	tCasilla cas;
	switch (c) {
	case '#':	cas.contenido = MURO; break;
	case '@':	cas.contenido = HIELO; break;
	case ' ':	cas.contenido = VACIA; break;
	case '$':	cas.contenido = JOYA; break;
	case 'C':	cas.contenido = CAJA; break;
	default:
		cas.contenido = TORTUGA;
		cas.tortuga.identificacion = n;
		switch (c) {
		case 'U':	cas.tortuga.direccion = UP; break;
		case 'D':	cas.tortuga.direccion = DOWN; break;
		case 'R':	cas.tortuga.direccion = RIGHT; break;
		case 'L':	cas.tortuga.direccion = LEFT; break;
		}
	}
	return cas;
}
//(b) Transformar una casilla en una cadena de caracteres.
void colorFondo(int color) {
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(handle, 15 | (color << 4));
}
void colorFondo(int color, int letra) {
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(handle, letra | (color << 4));
}
std::string casillaTOstr(tCasilla c) {
	switch (c.contenido) {
	case VACIA: {
		colorFondo(PALETA[0]);
		return "  ";
	}
	case HIELO: {
		colorFondo(PALETA[1]);
		return "**";
	}
	case MURO: {
		colorFondo(PALETA[2]);
		return "||";
	}
	case CAJA: {
		colorFondo(PALETA[3]);
		return "[]";
	}
	case JOYA: {
		colorFondo(PALETA[4]);
		return "00";
	}
	case TORTUGA: {
		colorFondo(PALETA[c.tortuga.identificacion + 4], 0);
		switch (c.tortuga.direccion) {
		case UP: {
			return"^^";
		}
		case DOWN: {
			return"vv"; }
		case RIGHT: {
			return">>"; }
		case LEFT: {
			return"<<";
		}
		}
	}
	}
}

//(c) Mostrar por pantalla o ?chero una casilla. 
void mostrarCasilla(tCasilla cas) {
	std::cout << casillaTOstr(cas);
}
//(d) Mostrar por pantalla o fichero un tablero.
void mostrarTablero(tTablero const& t) {
	for (int f = 0; f < t.size(); ++f) {
		for (int c = 0; c < t.size(); ++c) {
			mostrarCasilla(t[f][c]);
		}
		colorFondo(0);
		std::cout << '\n';
	}
}
//(e) Cargar un tablero a partir de unos datos dados por teclado o fichero.
bool cargar(tTablero & t, int n, std::string const & nombreFich) {
	std::ifstream entrada;
	entrada.open(nombreFich);
	if (entrada.is_open()) {
		std::string linea;
		getline(entrada, linea);
		std::stringstream ss; ss << linea;
		int numParticipantes;
		ss >> numParticipantes;
		while (numParticipantes != n) {
			int i = 0;
			while (i < 8) {
				getline(entrada, linea);
				++i;
			}
			getline(entrada, linea);
			ss.clear();
			ss << linea;
			ss >> numParticipantes;
		}
		int tortCont = 1;
		for (int f = 0; f < t.size(); ++f) {
			std::string str = "";
			getline(entrada, str);
			for (int c = 0; c < t.size(); ++c) {
				t[f][c] = charTOcasilla(str[c], tortCont);
				if (t[f][c].contenido == TORTUGA)++tortCont;
			}
		}
		entrada.close();
		return true;
	}
	else {
		std::cout << "No pudo cargarse el tablero. Puede que no exista dicho archivo.\n";
		return false;
	}
}
//(f)funcion que comprueba que las coordenadas estan dentro del tablero
bool dentroTablero(tTablero const & t, tCoordenada & c) {
	return c.fila < DIMENSION && c.columna<DIMENSION && c.fila >= 0 && c.columna >= 0;
}
//(g) Fucion que reciba un tablero, las coordenadas en que se encuentra la tortuga con la pistola laser y la direccion a la que apunta la tortuga y modiﬁque el tablero de acuerdo con el resultado del disparo
void laser(tTablero & t, tCoordenada pos, tDir & disparo) {
	bool ejecutado = false;
	while (!ejecutado && dentroTablero(t, pos + tCoordenada{ incF[disparo] ,incC[disparo] })) {
		pos.fila += incF[disparo];
		pos.columna += incC[disparo];
		if (t[pos.fila][pos.columna].contenido == HIELO) {
			t[pos.fila][pos.columna].contenido = VACIA;
			ejecutado = true;
		}
		else if (t[pos.fila][pos.columna].contenido != VACIA) {
			ejecutado = true;
		}
	}
}
//(h)Funcion que comprueba si un movimiento es posible
bool movPosible(tTablero const & t, tCoordenada c, tDir & dir) {
	bool posible = false;
	if (dentroTablero(t, c + tCoordenada{ incF[dir] ,incC[dir] })) {
		c.fila += incF[dir];
		c.columna += incC[dir];
		if (t[c.fila][c.columna].contenido == VACIA || t[c.fila][c.columna].contenido == JOYA) {
			posible = true;
		}
		else if (t[c.fila][c.columna].contenido == CAJA && dentroTablero(t, c + tCoordenada{ incF[dir] ,incC[dir] }) && (t[c.fila + incF[dir]][c.columna + incC[dir]].contenido == VACIA)) {
			posible = true;
		}
	}
	return posible;
}
//funcion que avanza una casilla en la direccion dada. Devuelve cierto si encuentra la joya
bool avanzar(tTablero  & t, tCoordenada & c, tDir & d) {
	bool joya = false;
	if (t[c.fila + incF[d]][c.columna + incC[d]].contenido == VACIA) {
		std::swap(t[c.fila + incF[d]][c.columna + incC[d]], t[c.fila][c.columna]);
	}
	else if (t[c.fila + incF[d]][c.columna + incC[d]].contenido == CAJA) {
		std::swap(t[c.fila + incF[d]][c.columna + incC[d]], t[c.fila][c.columna]);
		std::swap(t[c.fila + incF[d] + incF[d]][c.columna + incC[d] + incC[d]], t[c.fila][c.columna]);
	}
	else if (t[c.fila + incF[d]][c.columna + incC[d]].contenido == JOYA) {
		t[c.fila + incF[d]][c.columna + incC[d]] = t[c.fila][c.columna];
		t[c.fila][c.columna].contenido = VACIA;
		joya = true;
	}
	c.fila += incF[d];
	c.columna += incC[d];
	return joya;
}
