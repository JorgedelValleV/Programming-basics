// Nombre del alumno .....Jorge del Valle Vazquez
// Usuario del Juez ......DG206

#ifndef PUNTUACIONES_H
#define PUNTUACIONES_H

#include<iostream>
#include<string>
#include<fstream>
#include<vector>
const int TAM = 4;
const std::string ARCHIVO_CLASIFICACION = "puntuaciones.txt";
const std::string ERROR_AL_GUARDAR_PUNTUACIONES = "Hubo un error al guardar las puntuaciones en el archivo.\n";
struct tPlayer {
	std::string nombre;
	int puntuacion;
};
struct tPuntuaciones {
	int capacidad;
	int numJugadores;
	tPlayer ** array_clasificacion;
};

bool compdefecto(tPlayer* p1, tPlayer* p2);
bool compalfab(tPlayer* p1, tPlayer* p2);
//funcion que carga las puntuaciones de un archivo en un vector
bool cargar(tPuntuaciones & t);
//funcion que escribe en un fichero las puntuaciones guardadas en un vector al final de la partida
void guardarPuntuaciones(const tPuntuaciones & puntos);
//funcion que muestra por pantalla las puntuaciones guardadas en un vector dinamico ordenadas por defecto
void mostrarPuntuaciones(const tPuntuaciones & puntos);
//funcion que muestra por pantalla las puntuaciones ordenadas alfabeticamente
void mostrarAlfabetico(const tPuntuaciones & punt);
//funcion que busca un nombre en un vector y devuelve su posicion, si no lo encuentra devuelve el valor -1, que sirve para identificar al jugador que hay que anadir al vector
int encontrarNombre(tPuntuaciones const & puntos, const std::string & str);
//funcion que busca un nombre en la clasificacion.
bool buscarnomb(tPuntuaciones const & punt, std::string const & str, int & pos);
//funcion que busca la posicion que le corresponde a un jugador en la clasificacion.
bool buscar(tPuntuaciones const & punt, tPlayer & p, int & pos);
//funcion que dado un jugador con su puntuacion, si ya esta en el vector le suma la puntuacion, y si no esta lo incorpora en la posicion que le corresponda determinada por la funcion buscar
bool actualizarPuntuacion(tPuntuaciones & puntos, tPlayer & p);
void redimensionar(tPuntuaciones & clasificacion);
void liberar(tPuntuaciones & clasificacion);
#endif